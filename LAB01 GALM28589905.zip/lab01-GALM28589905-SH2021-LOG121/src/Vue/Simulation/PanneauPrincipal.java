package Vue.Simulation;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import Modele.Production.Composant;
import Modele.Production.Usine;

public class PanneauPrincipal extends JPanel {

	private static final long serialVersionUID = 1L;

	BufferedImage image = null;

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		afficherUsines(g);
		afficherChemins(g);
		gestionAfficherComposants(g);

	}

	// Permet d'afficher les icones des usines
	public void afficherUsines(Graphics g) {
		int positionX = 0;
		int positionY = 0;
		String icone = "";
		try {
			if (Usine.getListeUsines() != null) {
				for (int i = 0; i < Usine.getListeUsines().size(); i++) {
					Usine usine = Usine.getListeUsines().get(i);
					positionX = Integer.parseInt(usine.getPositionX());
					positionY = Integer.parseInt(usine.getPositionY());
					if (Environnement.getTour() >= usine.getIntervalleProduction()) {
						if ((Environnement.getTour() % (usine.getIntervalleProduction() / 3)) == 0) {
							icone = usine.getIconeUnTiers();
						} else if ((Environnement.getTour() % (usine.getIntervalleProduction() * 2 / 3)) == 0) {
							icone = usine.getIconeDeuxTiers();
						} else if ((Environnement.getTour() % usine.getIntervalleProduction()) == 0) {
							icone = usine.getIconePlein();
						} else {
							icone = usine.getIconeVide();
						}
					} else {
						icone = usine.getIconeVide();
					}
					image = ImageIO.read(new File(icone));
					g.drawImage(image, positionX, positionY, null);
				}
			}
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	// permet daffiher le chemins qui sont relier entre les usines
	public void afficherChemins(Graphics g) {
		int positionXDepart = 0, positionYDepart = 0, positionXDestination = 0, positionYDestination = 0;
		String idDepart = "";
		String idDestination = "";
		if (Usine.getListeChemins() != null) {
			for (int i = 0; i < Usine.getListeChemins().size(); i++) {
				if ((i % 2) == 0) {
					idDepart = Usine.getListeChemins().get(i);
				} else {
					idDestination = Usine.getListeChemins().get(i);

					for (int j = 0; j < Usine.getListeUsines().size(); j++) {
						if (Usine.getListeUsines().get(j).getID().equals(idDepart)) {
							positionXDepart = Integer.parseInt(Usine.getListeUsines().get(j).getPositionX())
									+ image.getHeight() / 2;
							positionYDepart = Integer.parseInt(Usine.getListeUsines().get(j).getPositionY())
									+ image.getHeight() / 2;
						}
						if (Usine.getListeUsines().get(j).getID().equals(idDestination)) {
							positionXDestination = Integer.parseInt(Usine.getListeUsines().get(j).getPositionX())
									+ image.getHeight() / 2;
							positionYDestination = Integer.parseInt(Usine.getListeUsines().get(j).getPositionY())
									+ image.getHeight() / 2;
						}
					}
					g.drawLine(positionXDepart, positionYDepart, positionXDestination, positionYDestination);
				}
			}
		}
	}

	public void afficherComposants(Graphics g, Usine usine) {
		int deplacementX = 0;
		int deplacementY = 0;
		int positionXDestination = 0, positionYDestination = 0;
		String idDestination = "";
		Composant composant = null;
		Usine usineDestination = null;

		try {

			if (!usine.getID().equals("51")) {
				ArrayList<Composant> composantSortie = usine.getComposantSortie();
				for (int i = 0; i < composantSortie.size(); i++) {
					if (composantSortie.get(i) != null) {
						composant = composantSortie.get(i);
						String icone = composant.getIcone();
						if (usine.getID().equals("13") || usine.getID().equals("31")) {
							deplacementX = -2;
							deplacementY = -2;
						} else if (usine.getID().equals("21")) {
							deplacementX = -2;
							deplacementY = 2;
						} else {
							deplacementX = 2;
							deplacementY = 0;
						}
						for (int y = 0; y < Usine.getListeChemins().size(); y++) {
							if ((y % 2) == 1 && usine.getID().equals(Usine.getListeChemins().get(y))) {
								idDestination = Usine.getListeChemins().get(y - 1);
								for (int j = 0; j < Usine.getListeUsines().size(); j++) {
									if (Usine.getListeUsines().get(j).getID().equals(idDestination)) {
										positionXDestination = Integer
												.parseInt(Usine.getListeUsines().get(j).getPositionX());
										positionYDestination = Integer
												.parseInt(Usine.getListeUsines().get(j).getPositionY());
										usineDestination = Usine.getListeUsines().get(j);
									}
								}
							}
						}
						if (composant.getPositionX() != positionXDestination
								|| composant.getPositionY() != positionYDestination) {
							composant.deplacerComposant(deplacementX, deplacementY);
							image = ImageIO.read(new File(icone));
							g.drawImage(image, composant.getPositionX(), composant.getPositionY(), null);
						} else if (composant.getPositionX() == positionXDestination
								|| composant.getPositionY() != positionYDestination) {
							usineDestination.addQuantiteStock();

							composantSortie.remove(i);
						}

					}
				}
			}
		} catch (IOException io) {
			io.printStackTrace();

		}
	}

	public void gestionAfficherComposants(Graphics g) {
		if (Usine.getListeUsines() != null) {
			for (int i = 0; i < Usine.getListeUsines().size(); i++) {
				Usine usine = Usine.getListeUsines().get(i);
				if (!usine.getID().equals("51")) {
					afficherComposants(g, usine);
					if (usine.getIntervalleProduction() <= Environnement.getTour()
							&& (Environnement.getTour() % usine.getIntervalleProduction()) == 0) {
						usine.setComposantSortie();
						afficherComposants(g, usine);
					}
				}
			}
			// }
		}
	}

}
