package Controlleur;

import java.util.ArrayList;
import java.util.HashMap;

import Modele.Production.Entrepot;
import Modele.Production.Usine;
import Modele.Production.UsineAile;
import Modele.Production.UsineAssemblage;
import Modele.Production.UsineMatiere;
import Modele.Production.UsineMoteur;

public class Controlleur {
	private HashMap<String, String> hMapIcones;
	private HashMap<String, String> hMapComposantsEntree;
	private String composantSortie;
	private String intervalleProduction;
	private String positionY;
	private String positionX;
	private String id;
	private XMLReader lecteurXMLSimulation;
	private XMLReader lecteurXMLMetadonnees;
	private HashMap<String, String> hMapChemins;
	private String filePath;
	//private Usine usine;

	public Controlleur(String filePath) {
		this.filePath = filePath;
		this.lecteurXMLSimulation = new XMLReader(filePath);
		//this.usine = new Usine();
		instanciationUsines();
		setListeChemins();

	}

	public void getInformationsMetadonneesUsines(String typeUsine) {
		this.lecteurXMLMetadonnees = new XMLReader(this.filePath);
		lecteurXMLMetadonnees.setListeActuelle("metadonnees");
		lecteurXMLMetadonnees.setListeActuelle("usine");
		ArrayList<String> listeUsines = lecteurXMLMetadonnees.getListeActuelleToString("type");
		for (int i = 0; i < listeUsines.size(); i++) {
			if (listeUsines.get(i).equals(typeUsine)) {
				if (typeUsine.equals("usine-matiere")) {
					getInformationsUsineMatiere();
				} else if (typeUsine.equals("usine-aile")) {
					getInformationsUsineAile();
				} else if (typeUsine.equals("usine-moteur")) {
					getInformationsUsineMoteur();
				} else if (typeUsine.equals("usine-assemblage")) {
					getInformationsUsineAssemblage();
				} else {
					getInformationsEntrepot();
				}
				break;
			} else {
				lecteurXMLMetadonnees.elementSuivantListe();
			}
		}
		
	}

	public void instanciationUsines() {
		lecteurXMLSimulation.setListeActuelle("simulation");
		lecteurXMLSimulation.setListeActuelle("usine");
		ArrayList<String> listeUsines = lecteurXMLSimulation.getListeActuelleToString("type");
		for (int i = 0; i < listeUsines.size(); i++) {
			if (listeUsines.get(i).equals("usine-matiere")) {
				getInformationsMetadonneesUsines("usine-matiere");
				getInformationsSimulationUsines(i);
				Usine instancierUsine = new Modele.Production.UsineMatiere("usine-matiere", hMapIcones, composantSortie, intervalleProduction, positionY,
						positionX, id);
				Usine.addListeUsines(instancierUsine);
			} else if (listeUsines.get(i).equals("usine-aile")) {
				getInformationsMetadonneesUsines("usine-aile");
				getInformationsSimulationUsines(i);
				Usine instancierUsine = new UsineAile("usine-aile", hMapIcones, hMapComposantsEntree, composantSortie, intervalleProduction,
						positionY, positionX, id);
				Usine.addListeUsines( instancierUsine);
			} else if (listeUsines.get(i).equals("usine-moteur")) {
				getInformationsMetadonneesUsines("usine-moteur");
				getInformationsSimulationUsines(i);
				Usine instancierUsine = new UsineMoteur("usine-moteur",hMapIcones, hMapComposantsEntree, composantSortie,
						intervalleProduction, positionY, positionX, id);
				Usine.addListeUsines( instancierUsine);
			} else if (listeUsines.get(i).equals("usine-assemblage")) {
				getInformationsMetadonneesUsines("usine-assemblage");
				getInformationsSimulationUsines(i);
				Usine instancierUsine = new UsineAssemblage("usine-assemblage", hMapIcones, hMapComposantsEntree, composantSortie,
						intervalleProduction, positionY, positionX, id);
				Usine.addListeUsines(instancierUsine);
			} else {
				getInformationsMetadonneesUsines("entrepot");
				getInformationsSimulationUsines(i);
				Usine instancierUsine = new Entrepot("entrepot", hMapIcones, hMapComposantsEntree, positionY, positionX, id);
				Usine.addListeUsines(instancierUsine);
			}
			lecteurXMLSimulation.elementSuivantListe();
		}

	}

	public void getInformationsSimulationUsines(int index) {
		setPositionY(index);
		setPositionX(index);
		setId(index);
	}

	public void getInformationsUsineMatiere() {
		setHMmapIcones();
		setComposantSortie();
		setIntervalleProduction();
	}

	public void getInformationsUsineAile() {
		setHMmapIcones();
		setHMmapComposantsEntree("quantite");
		setComposantSortie();
		setIntervalleProduction();
	}

	public void getInformationsUsineMoteur() {
		setHMmapIcones();
		setHMmapComposantsEntree("quantite");
		setComposantSortie();
		setIntervalleProduction();
	}

	public void getInformationsUsineAssemblage() {
		setHMmapIcones();
		setHMmapComposantsEntree("quantite");
		setComposantSortie();
		setIntervalleProduction();
	}

	public void getInformationsEntrepot() {
		setHMmapIcones();
		setHMmapComposantsEntree("capacite");
	}

	public void setHMmapComposantsEntree(String information) {
		this.hMapComposantsEntree = lecteurXMLMetadonnees.getHMapInformations("entree", "type", information);
	}

	public void setHMmapIcones() {
		this.hMapIcones = lecteurXMLMetadonnees.getHMapInformations("icone", "type", "path");
	}

	public void setComposantSortie() {
		this.composantSortie = lecteurXMLMetadonnees.getInformation("sortie", "type");
	}

	public void setIntervalleProduction() {
		this.intervalleProduction = lecteurXMLMetadonnees.getInformation("interval-production", null);
	}

	public void setPositionY(int index) {
		this.positionY = lecteurXMLSimulation.getInformationAttribut("y", index);
	}

	public void setPositionX(int index) {
		this.positionX = lecteurXMLSimulation.getInformationAttribut("x", index);
	}

	public void setId(int index) {
		this.id = lecteurXMLSimulation.getInformationAttribut("id", index);
	}
	
	public void setListeChemins() {
		lecteurXMLSimulation.resetRoot();
		lecteurXMLSimulation.setListeActuelle("simulation");
		Usine.setListeChemins(lecteurXMLSimulation.getListeInformations("chemin", "vers", "de"));
	}

}
