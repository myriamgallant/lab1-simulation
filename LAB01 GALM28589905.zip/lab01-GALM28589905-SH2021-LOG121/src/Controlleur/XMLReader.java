package Controlleur;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class XMLReader {
	private String filePath;
	private NodeList listeActuelle;
	private Document document;
	private Element root;
	private Element eElement;
	private int index;

	/*
	 * / constructeur public pour le LecteurXML
	 */
	public XMLReader(String filePath) {
		this.filePath = filePath;
		this.listeActuelle = null;
		this.index = 0;
		readDocument();

	}

	public void readDocument() {
		try {
			// cr�ation du document builder
			// Instancier la Factory qui permet d'acc�der � un parser (appel�
			// DocumentBuilder)
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			// R�cup�rer le parser
			DocumentBuilder builder = factory.newDocumentBuilder();
			// parser le fichier XML
			Document document = builder.parse(new File(this.filePath));
			document.getDocumentElement().normalize();
			this.document = document;
		} catch (Exception e) {
			e.printStackTrace();
		}
		// acc�s � la racine du document
		this.root = document.getDocumentElement();
		this.eElement = this.root;
	}

	public void setListeActuelle(String nomListe) {
		NodeList liste = eElement.getElementsByTagName(nomListe);
		this.listeActuelle = liste;
		this.eElement = (Element) listeActuelle.item(0);
	}

	public void resetRoot() {
		this.eElement = this.root;
		this.listeActuelle = null;

	}

	public ArrayList<String> getListeActuelleToString(String attribut) {
		ArrayList<String> stringListe = new ArrayList<>();
		for (int i = 0; i < listeActuelle.getLength(); i++) {
			Element element = (Element) listeActuelle.item(i);
			stringListe.add(element.getAttribute(attribut));
		}
		return stringListe;
	}

	public HashMap<String, String> getHMapInformations(String tag, String attribut1, String attribut2) {
		HashMap<String, String> hmap = new HashMap<>();
		NodeList liste = eElement.getElementsByTagName(tag);
		try {
			for (int y = 0; y < liste.getLength(); y++) {
				Node nNoeud = liste.item(y);
				if (nNoeud.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) nNoeud;
					hmap.put(element.getAttribute(attribut1), element.getAttribute(attribut2));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hmap;
	}

	public ArrayList<String> getListeInformations(String tag, String attribut1, String attribut2) {
		ArrayList<String> listeArray = new ArrayList<>();
		NodeList liste = eElement.getElementsByTagName(tag);
		try {
			for (int y = 0; y < liste.getLength(); y++) {
				Node nNoeud = liste.item(y);
				if (nNoeud.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) nNoeud;
					listeArray.add(element.getAttribute(attribut1));
					listeArray.add(element.getAttribute(attribut2));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listeArray;
	}

	public String getInformation(String tag, String attribut) {
		NodeList liste = eElement.getElementsByTagName(tag);
		String information = null;
		try {
			for (int y = 0; y < liste.getLength(); y++) {
				Node nNoeud = liste.item(y);
				if (nNoeud.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) nNoeud;
					if (attribut == null) {
						information = element.getTextContent();
					} else {
						information = element.getAttribute(attribut);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return information;
	}

	public void elementSuivantListe() {
		this.index++;
		this.eElement = (Element) listeActuelle.item(index);
	}

	public String getInformationAttribut(String attribut, int index) {
		String information = null;
		Node nNoeud = listeActuelle.item(index);
		if (nNoeud.getNodeType() == Node.ELEMENT_NODE) {
			Element element = (Element) nNoeud;
			information = element.getAttribute(attribut);

		}
		return information;
	}

}
