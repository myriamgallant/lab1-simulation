package Modele.Vente;

public interface StrategieVente {

}
