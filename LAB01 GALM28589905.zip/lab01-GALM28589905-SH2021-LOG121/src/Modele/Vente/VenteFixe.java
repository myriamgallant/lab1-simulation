package Modele.Vente;

public class VenteFixe {

}
