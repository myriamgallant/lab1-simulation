package Modele.Vente;

public class VenteAleatoire {

}
