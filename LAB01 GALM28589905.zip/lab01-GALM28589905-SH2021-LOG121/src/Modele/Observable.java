package Modele;

public class Observable {

}
