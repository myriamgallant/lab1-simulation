package Modele;

public class ObserverEntrepot extends Observer{
	public ObserverEntrepot(Subject subject) {
		this.subject = subject;
		this.subject.attach(this);
	}

	@Override
	public void update() {
		System.out.println("Binary String: " + Integer.toBinaryString(subject.getState()));
	}
}
