package Modele.Production;

import java.awt.Point;

public class Composant {
	
		private int positionX;
		private int positionY;
		private String iconeComposant;
		private String type;
		
		public Composant(String type, String iconeComposant, String positionX, String positionY) {
			this.iconeComposant = iconeComposant ;
			this.type = type;
			this.positionX = Integer.parseInt(positionX);
			this.positionY = Integer.parseInt(positionY);
		}

		public Composant(int positionX, int positionY) {
			setPosition(positionX, positionY);
		}

		public void setPosition(int positionX, int positionY){
	        this.positionX = positionX;
	        this.positionY = positionY;
	    }
		public String getIcone() {
			return this.iconeComposant;
		}
		
		public void setIcones(String icone) {
			this.iconeComposant = icone;
			
		}
		public void deplacerComposant(int positionX,int positionY) {
			this.positionX += positionX ;
			this.positionY +=positionY;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public int getPositionX() {
			return positionX;
		}

		public void setPositionX(int positionX) {
			this.positionX = positionX;
		}

		public int getPositionY() {
			return positionY;
		}

		public void setPositionY(int positionY) {
			this.positionY = positionY;
		}
	
}
