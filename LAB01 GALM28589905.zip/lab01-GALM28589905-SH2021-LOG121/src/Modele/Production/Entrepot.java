package Modele.Production;

import java.util.HashMap;

public class Entrepot extends Usine{

	public Entrepot(String type, HashMap<String, String> hMapIcones, HashMap<String, String> hMapComposantsEntree,
		String positionY, String positionX, String id) {
			super(type, hMapIcones, positionY, positionX, id);
			setComposantEntree(hMapComposantsEntree);
			
			
			//A ENLEVER
			setIntervalleProduction(6);
	}

}
