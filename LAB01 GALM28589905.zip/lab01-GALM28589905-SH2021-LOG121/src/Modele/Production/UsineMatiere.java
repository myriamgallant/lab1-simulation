package Modele.Production;

import java.util.HashMap;
import Modele.Subject;

public class UsineMatiere extends Usine implements Subject {

	public UsineMatiere(String type, HashMap<String, String> hMapIcones, String composantSortie,
			String intervalleProduction, String positionY, String positionX, String id) {
		super(type, hMapIcones, positionY, positionX, id);
		setComposantSortie(composantSortie);
		setComposantSortie();
		setIntervalleProduction(Integer.parseInt(intervalleProduction));
	}
	
	

}
