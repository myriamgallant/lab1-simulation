package Modele.Production;

import java.util.HashMap;

public class UsineMoteur extends Usine{

	public UsineMoteur(String type, HashMap<String, String> hMapIcones, HashMap<String, String> hMapComposantsEntree,
			String composantSortie, String intervalleProduction, String positionY, String positionX, String id) {
		super(type, hMapIcones, positionY, positionX, id);
		setComposantEntree(hMapComposantsEntree);
		setComposantSortie(composantSortie);
		setIntervalleProduction(Integer.parseInt(intervalleProduction));
	}

}
