package Modele.Production;

import java.awt.Component;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import Modele.Observer;

public abstract class Usine {

	// template des usines
	private String type;
	private final String pathStart = "src\\ressources\\";
	private final String pathEnd = ".png";
	private HashMap<String, String> hMapIcones;
	private String positionX;
	private String positionY;
	private String id;
	private int intervalleProduction;
	private static ArrayList<Usine> listeUsines = new ArrayList<Usine>();;
	private static ArrayList<String> listeChemins = new ArrayList<String>();;
	// private ArrayList<String> listIconUsines = new ArrayList<>();
	private Composant composantEntree;
	private int quantiteRequise;
	private ArrayList<Composant> composantSortie;
	private String composantSortieName;
	private int quantiteStock;
	private List<Observer> observers = new ArrayList<Observer>();
	private int state;
	private HashMap<String,Integer> hMapQuantiteStock;
	private HashMap<String, Integer> hMapComposantsEntree = new HashMap<String,Integer>();

	public Usine(String type, HashMap<String, String> hmapIcones, String positionY, String positionX, String id) {
		this.type = type;
		this.id = id;
		this.positionX = positionX;
		this.positionY = positionY;
		this.hMapIcones = hmapIcones;
		this.intervalleProduction = 0;
		this.quantiteStock = 0;
		

	}

	public void setPositionX(String positionX) {

		this.positionX = positionX;
	}

	public String getPositionX() {

		return positionX;
	}

	public void setPositionY(String positionY) {

		this.positionY = positionY;
	}

	public String getPositionY() {

		return positionY;
	}

	public void setID(String id) {
		this.id = id;
	}

	public String getID() {

		return id;
	}

	public void setIntervalleProduction(int intervalleProduction2) {
		this.intervalleProduction = intervalleProduction2;
	}

	public int getIntervalleProduction() {
		return this.intervalleProduction;
	}

	public void intervalleProductionTour() {

		intervalleProduction += 1;
	}

	/*
	 * public void addListeIconUsines(String icon) {
	 * 
	 * listIconUsines.add(icon); }
	 * 
	 * public ArrayList<String> getListIconUsines() {
	 * 
	 * return listIconUsines; }
	 * 
	 * 
	 * 
	 * public Composant getComposanteEntree() {
	 * 
	 * return composantEntree; }
	 * 
	 * 
	 * 
	 * 
	 * 
	 * public int getQuantiteRequise() { return quantiteRequise; }
	 * 
	 * public void setQuantiteRequise(int quantiteRequise) { this.quantiteRequise =
	 * quantiteRequise; }
	 * 
	 * public int getQuantiteStock() { return quantiteStock; }
	 */
	public void setComposantEntree(HashMap<String, String> hMapComposantsEntree) {
		for (Entry<String, String> entry : hMapComposantsEntree.entrySet()) {
			String composant = entry.getKey();
			String quantite = entry.getValue();
			String chemin = pathStart + composant + pathEnd;
			composantEntree = new Composant(composant, chemin, positionX, positionY);
			this.hMapComposantsEntree.put(composant, Integer.parseInt(quantite));
			
		}

	}

	public void setComposantSortie(String composant) {

		this.setComposantSortieName(composant);
		this.composantSortie = new ArrayList<Composant>();

	}

	public void setComposantSortie() {
		String chemin = pathStart + this.composantSortieName + pathEnd;
		this.composantSortie.add(new Composant(composantSortieName, chemin, this.positionX, this.positionY));
	}

	public ArrayList<Composant> getComposantSortie() {
		return this.composantSortie;
	}

	public void addQuantiteStock() {
		this.quantiteStock++;
		;
	}

	public static void addListeUsines(Usine usine) {
		listeUsines.add(usine);
	}

	public static ArrayList<Usine> getListeUsines() {
		return listeUsines;
	}

	public void setHMapIcones(HashMap<String, String> hmapIcones) {
		this.hMapIcones = hmapIcones;
	}

	public static void setListeChemins(ArrayList<String> liste) {
		listeChemins.addAll(liste);
	}

	public String getIconeVide() {
		return this.hMapIcones.get("vide");
	}

	public String getIconeUnTiers() {
		return this.hMapIcones.get("un-tiers");
	}

	public String getIconeDeuxTiers() {
		return this.hMapIcones.get("deux-tiers");
	}

	public String getIconePlein() {
		return this.hMapIcones.get("plein");
	}

	public static ArrayList<String> getListeChemins() {

		return listeChemins;
	}

	public String getType() {
		return this.type;
	}

	public int getState() {
		return this.state;
	}

	public void setState(int state) {
		this.state = state;

	}

	public void attach(Observer observer) {
		observers.add(observer);

	}

	public void notifyAllObservers() {
		for (Observer observer : observers) {
			observer.update();
		}
	}

	public int getQuantiteRequise() {
		return quantiteRequise;
	}

	public int getQuantiteStock() {
		return this.quantiteStock;
	}

	public String getComposantSortieName() {
		return composantSortieName;
	}

	public void setComposantSortieName(String composantSortieName) {
		this.composantSortieName = composantSortieName;
	}

	

}
